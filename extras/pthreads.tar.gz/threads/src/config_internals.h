/* Copyright (C) 1992, 1993, 1994, 1995, 1996 the Florida State University
   Distributed by the Florida State University under the terms of the
   GNU Library General Public License.

This file is part of Pthreads.

Pthreads is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation (version 2).

Pthreads is distributed "AS IS" in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU Library General Public License for more details.

You should have received a copy of the GNU Library General Public
License along with Pthreads; see the file COPYING.  If not, write
to the Free Software Foundation, 675 Mass Ave, Cambridge,
MA 02139, USA.

Report problems and direct all questions to:

  pthreads-bugs@ada.cs.fsu.edu

  %@(#)config_header.c	3.14%11/8/00%
*/

/*
 * configuration header file to identify compile options
 */

#ifndef TDI_SUPPORT
#define TDI_SUPPORT
#endif

#ifndef NO_FIX_MALLOC
#define NO_FIX_MALLOC
#endif

#ifndef MALLOC
#define MALLOC
#endif

#ifndef IO
#define IO
#endif

#ifndef C_INTERFACE
#define C_INTERFACE
#endif

#ifndef SRP
#define SRP
#endif

#ifndef AUTO_INIT
#define AUTO_INIT
#endif

#ifndef _POSIX
#define _POSIX
#endif

#ifndef CLEANUP_HEAP
#define CLEANUP_HEAP
#endif

#ifndef C_CONTEXT_SWITCH
#define C_CONTEXT_SWITCH
#endif

#ifndef RELEASE
#define RELEASE 22.18
#endif

#ifndef _M_UNIX
#if defined(M_UNIX) || defined(__M_UNIX)
#define _M_UNIX
#endif
#endif

#define PTHREAD_SIGSET_T_SIZE_NP 128
#define PTHREAD_SIGCONTEXT_MASK_T_SIZE_NP 4
#define PTHREAD_SIGSET2SET_SIZE_NP 4
